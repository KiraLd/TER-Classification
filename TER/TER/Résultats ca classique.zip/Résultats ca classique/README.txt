Tests t�moins pour CA classique, avec distance euclidienne.
Image de test rgb, 256x256
Les dossiers contiennent les matrices d'appartenances des classes pour les 4 tests



Cluster lin�aire(triangle):

Param�tres:
Nombre de classe max: 5
Nombre de classe final: 2
m = 2
e = 0.01
nombre d'it�ration max: 500
it�ration max constat�: ~10
n0 = 1
seuil d'agglom�ration: 10

Cluster lin�aire bruit�(triangle):
Param�tres:
Nombre de classe max: 5
Nombre de classe final: 4
m = 2
e = 0.01
nombre d'it�ration max: 500
it�ration max constat�: ~90
n0 = 1
seuil d'agglom�ration: 10
->Inefficace, r�sultat biais� par le bruit

Cluster ellipse:
Param�tres:
Nombre de classe max: 10
Nombre de classe final: 4
m = 2
e = 0.01
nombre d'it�ration max: 500
it�ration max constat�: ~20
n0 = 1
seuil d'agglom�ration: 50

Cluster ellipse(bruit�):
Param�tres:
Nombre de classe max: 10
Nombre de classe final: 10
m = 2
e = 0.01
nombre d'it�ration max: 500
it�ration max constat�: ~60
n0 = 1
seuil d'agglom�ration: 50

